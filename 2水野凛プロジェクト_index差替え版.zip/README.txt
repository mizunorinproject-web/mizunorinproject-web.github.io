水野凛プロジェクト GitHub差替え版

このindex.htmlは、GitHubのルート直下に既にアップロード済みの画像を読み込むよう修正済みです。

操作
1. GitHub上の現在のindex.htmlだけを新しいindex.htmlで上書きしてください。
2. hero.jpeg、profile.jpegなどの画像は削除しないでください。
3. 上書き後、GitHub Pagesを有効にします。

公開予定URL
https://mizunorinproject-web.github.io
